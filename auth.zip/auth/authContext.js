import { createContext } from 'react';

// Create the AuthContext
export const AuthContext = createContext(null);
