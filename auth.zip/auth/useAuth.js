import { useContext } from 'react';
import { AuthContext } from './authContext';

// Named export
export const useAuth = () => {
  return useContext(AuthContext);
};
