import { createClient } from "@supabase/supabase-js"; 

export const supabase = createClient(
  "https://eaasjdksxcurvmrvqibm.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVhYXNqZGtzeGN1cnZtcnZxaWJtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQwMjUyMzcsImV4cCI6MjA0OTYwMTIzN30.7tDs4hENn2nJWg5HjeDrEN_3yXQS1tqOewXefx7Fc_8"
);
